// In file: app/src/main/java/com/artificialinsightsllc/teamsync/Screens/MarkerInfoDialog.kt
package com.artificialinsightsllc.teamsync.Screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat // Corrected to AutoMirrored if using latest Compose versions
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.artificialinsightsllc.teamsync.Helpers.TimeFormatter
import com.artificialinsightsllc.teamsync.Helpers.UnitConverter
import com.artificialinsightsllc.teamsync.R
import com.artificialinsightsllc.teamsync.ui.theme.DarkBlue
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarkerInfoDialog(
    profilePhotoUrl: String?,
    title: String,
    address: String?,
    timestamp: Long,
    speed: Float?,
    bearing: Float?,
    onDismissRequest: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var timeAgoString by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    LaunchedEffect(timestamp) {
        while (true) {
            timeAgoString = TimeFormatter.getRelativeTimeSpanString(timestamp).toString()
            delay(1000)
        }
    }

    LaunchedEffect(Unit) {
        sheetState.show()
    }

    ModalBottomSheet(
        onDismissRequest = {
            onDismissRequest()
        },
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        containerColor = Color.White.copy(alpha = 0.95f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth()
                .wrapContentHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Profile Picture
            Image(
                painter = rememberAsyncImagePainter(
                    model = profilePhotoUrl,
                    error = painterResource(id = R.drawable.default_profile_pic)
                ),
                contentDescription = "Profile Picture",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(Color.LightGray)
            )

            Text(
                text = title,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = DarkBlue,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(4.dp))

            // Address
            address?.let {
                Text(
                    text = it,
                    fontSize = 16.sp,
                    color = DarkBlue.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            } ?: Text(
                text = "Address: N/A",
                fontSize = 14.sp,
                color = DarkBlue.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            // Updated time
            Text(
                text = "Updated $timeAgoString",
                fontSize = 14.sp,
                color = DarkBlue.copy(alpha = 0.8f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            // Speed
            speed?.let {
                Text(
                    text = "Speed: ${String.format("%.1f", UnitConverter.metersPerSecondToMilesPerHour(it))} MPH",
                    fontSize = 14.sp,
                    color = DarkBlue.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Direction
            bearing?.let {
                Text(
                    text = "Direction: ${UnitConverter.getCardinalDirection(it)}",
                    fontSize = 14.sp,
                    color = DarkBlue.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(16.dp))

            // Row for the two action buttons at the bottom
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Private Chat Button (Bottom Left)
                Button(
                    onClick = {
                        Toast.makeText(context, "Private Chat for now...", Toast.LENGTH_SHORT).show()
                        // TODO: Navigate to private chat screen
                    },
                    // NEW: Increased button size to accommodate larger icon
                    modifier = Modifier
                        .size(80.dp) // Increased from 56.dp
                        .shadow(8.dp, CircleShape, clip = false),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = DarkBlue)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Chat,
                        contentDescription = "Private Chat",
                        tint = Color.White,
                        // NEW: Icon size adjusted to fit within the larger button
                        modifier = Modifier.size(40.dp) // Icon size now fits inside 80.dp button
                    )
                }

                // Close Button (Bottom Right)
                Button(
                    onClick = {
                        coroutineScope.launch {
                            sheetState.hide()
                        }.invokeOnCompletion {
                            onDismissRequest()
                        }
                    },
                    // NEW: Increased button size to accommodate larger icon
                    modifier = Modifier
                        .size(80.dp) // Increased from 56.dp
                        .shadow(8.dp, CircleShape, clip = false),
                    shape = CircleShape,
                    // NEW: Changed to specific maroon color
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF800000)) // Deep red/maroon
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = Color.White, // White tint for icon (contrast with maroon)
                        // NEW: Icon size adjusted to fit within the larger button
                        modifier = Modifier.size(40.dp) // Icon size now fits inside 80.dp button
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}